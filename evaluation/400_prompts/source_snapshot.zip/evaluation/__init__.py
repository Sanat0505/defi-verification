"""Reproducible thesis evaluation utilities."""
