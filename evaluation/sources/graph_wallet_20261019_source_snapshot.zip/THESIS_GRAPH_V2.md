# Thesis Knowledge Graph v2

The v2 ontology separates a protocol concept from each chain-specific
deployment. It is built alongside the legacy graph, so migration is
non-destructive.

## Canonical official graph

```text
ProtocolFamily
  └─ HAS_DEPLOYMENT → ProtocolDeployment
                          ├─ DEPLOYED_ON → Chain
Chain ─ HOSTS ────────────┘
                          ├─ DEPLOYED_CONTRACT → Contract
                          │                       └─ EXPOSES_FUNCTION → Function
                          │                                                  └─ IMPLEMENTS_ACTION → Action
                          ├─ SUPPORTS_ASSET → Token
                          ├─ SUPPORTS_ACTION → Action
                          ├─ HAS_POOL → Pool
                          └─ HAS_RESERVE → Reserve

Pool
  ├─ TOKEN0 → Token
  ├─ TOKEN1 → Token
  ├─ USES_FEE_TIER → FeeTier
  ├─ SUPPORTS_ACTION → Action
  └─ Factory ─ CREATED_POOL → Pool

Reserve
  ├─ UNDERLYING_ASSET → Token
  ├─ HAS_A_TOKEN → Contract
  ├─ HAS_VARIABLE_DEBT_TOKEN → Contract
  ├─ HAS_STABLE_DEBT_TOKEN → Contract
  ├─ HAS_STATIC_A_TOKEN → Contract
  ├─ USES_ORACLE → Contract
  ├─ USES_INTEREST_RATE_STRATEGY → Contract
  └─ SUPPORTS_ACTION → Action
```

The four deployment keys are:

- `uniswap-v3:1`
- `uniswap-v3:11155111`
- `aave-v3:1`
- `aave-v3:11155111`

## Three graph layers

1. The canonical graph contains official Mainnet and Sepolia deployments.
2. `GraphView {key: 'thesis-demo-v2'}` selects a readable subset of real data.
3. `FixtureGraph {key: 'fixture-root'}` contains deterministic approved and
   blocked security scenarios without influencing the main verifier.

Run `python -m db.sync` to synchronize all three layers. Useful Neo4j
visualization queries are in `db/V2_QUERIES.cypher`.

## Pool discovery and the current admission policy

The Aave loader reads every current core contract constant and every reserve
from the official Aave address book. This includes mixed-case symbols such as
`wstETH` and related aToken, variable/stable debt token, oracle, static aToken,
and interest-rate-strategy contracts when the address book publishes them.

The canonical graph stores every pool returned by its configured factory scan,
including token endpoints, fee tiers and relationships. In the current code, a
pool becomes verification-eligible only when both endpoint assets belong to
active Aave reserves on the same chain or are canonical WETH. The deployment
records discovered, accepted and excluded pool counts.

This is a local prototype admission rule, not an official Uniswap-to-Aave
membership requirement. Excluded pools have not thereby been classified as
malicious. Factory provenance and token safety are separate claims. The
[proposed Uniswap diagram](output/documents/Uniswap_V3_Graph_Proposed.tex)
describes the intended independent structure; it has not changed the loader or
the historical evaluation snapshot. Final evaluation references must be reviewed
against the policy actually frozen for that run.

Set both `MAINNET_RPC` and `SEPOLIA_RPC` for complete factory scans. Without a
Mainnet RPC, only the two curated real Mainnet pools are available and the
deployment is explicitly marked `pool_discovery_complete=false`; it must not be
described as complete in the evaluation.

Each synchronization marks old reserve, pool, and deployment-contract
relationships inactive before reactivating current official data. The verifier
uses only active relationships and also requires an authorized ABI function and
selector, not merely a trusted contract address.

After loading, run `python -m db.validate_graph_v2`. It prints the per-deployment
asset/contract/pool/function inventory and exits non-zero if a required
relationship is missing.

The legacy nodes remain available for comparison, but application verification
now queries only `ProtocolFamily` and `ProtocolDeployment` from the v2 model.

`db/loaders/` contains source parsers and RPC helpers. The superseded writers
for the old `Protocol` schema have been removed; use `python -m db.sync` or
the schema-initializing `python -m db.graph_builder` entry point for current
synchronization. Existing graph data and migration helpers are retained.
