# Evaluation plan

Graph-Based Verification of LLM-Generated DeFi Intents

Updated 15 October 2026 from the supplied five-page
[Revised Evaluation Plan](output/pdf/Revised_Evaluation_Plan_2026-10-14.pdf).
This Markdown version consolidates repeated passages in that document and
retains its proposed experiments, counts, limitations and supervisor questions.

**Status update, 19 October 2026:** final held-out Experiments A–C are **NOT YET
EVALUATED**. A 400-prompt proposal exists but requires human review, leakage and
independence adjudication, and freezing. The 72 relationship cases and 12
knowledge-lifecycle scenarios have been run as controlled implementation tests;
their references remain assistant-drafted and require researcher review. The
sample-size assumptions still require supervisor confirmation. See the
[evidence-based report](evaluation/thesis_final_report/00_EVALUATION_STATUS.md)
for completed observations, harness limitations and remaining work. The methodology
below remains the proposed final design, not a claim of final accuracy.

## 1. Purpose and scope

Evaluate whether the prototype understands a request, verifies its required
execution relationships and prevents unsupported operations from being approved.

- Uniswap V3: exact-input ERC-20 swaps.
- Aave V3: supply, withdraw, borrow and repay.
- Network: Ethereum Sepolia, chain ID `11155111`.
- Other protocols, networks and actions are boundary cases outside this scope.

The main path is:

```text
User request -> LLM -> intent validation -> graph verifier -> decision and evidence
```

Graph approval means consistency with the accepted knowledge represented in the
graph. It does not establish sufficient funds, collateral, wallet readiness or
successful transaction execution. Main experiments stop before submission;
wallet and handover tests are supplementary. Broadcasting is outside this plan.

## 2. Evaluation questions

| Question | Requirement | What the experiment should establish |
|---|---|---|
| Q1: Intent | R1 | Correct extraction of action, protocol, tokens, amount, network and stated constraints |
| Q2: Graph | R2, R3 | Correct distinction between valid relationships, wrong relationships, stale knowledge and incomplete knowledge |
| Q3: Complete pipeline | R1-R3 | Correct interpretation and final disposition without lost constraints |
| Q4: Time | R6 | At least 95% of eligible graph-verification requests complete within two seconds |
| Q5: Evidence | R5 | Approvals and non-approvals identify the expected graph path or reason |
| Q6: Handover | R4 | Changed, expired, reused or unapproved operations are stopped before submission |

## 3. Held-out requests and reference outcomes

Construct **400 prompts from 200 scenario families**, with two meaning-preserving
wordings per family. Earlier development requests must not be reused as untouched
final test cases. The second wording measures paraphrase consistency.

| Request category | Scenario families | Prompts |
|---|---:|---:|
| Valid Uniswap swaps | 30 | 60 |
| Valid Aave lending requests | 30 | 60 |
| Known entities with incorrect relationships | 40 | 80 |
| Unknown or unsupported scope | 40 | 80 |
| Incomplete or ambiguous requests | 30 | 60 |
| Invalid parameters or unsupported conditions | 30 | 60 |
| **Total** | **200** | **400** |

Preselect one primary wording per family before testing. The primary analysis
therefore contains **60 approvable and 140 non-approvable scenarios**. A
non-approvable scenario does not necessarily require `REJECTED`: clarification,
unsupported scope and insufficient evidence must retain their own meanings.

### Sources and selection

Most candidate Uniswap requests will come from the Uniswap examples in
INTENT-TX-18K [1]. Its intent-transaction alignment labels are not ground truth
for this graph-verification task. Aave requests use the Pool documentation [2];
Uniswap semantics are checked against the V3 guide [3]. Thus the complete
benchmark is not simply a sample of unchanged INTENT-TX-18K records.

Review action, assets, amount, network and explicit conditions such as slippage.
Compatible requests may become positive cases after reference review; unsupported
conditions may become explicitly labelled boundary cases. Adaptations to Sepolia
or V3 must preserve the meaning or document each change. Record:

- Original source ID and selected source-repository commit.
- Filtering reason and every modification.
- Whether the request is unchanged, adapted or researcher-written.
- Scenario-family ID, both wordings and the preselected primary wording.
- Human-reviewed reference intent, validation outcome and expected graph result.
- Independent protocol/graph evidence supporting the reference labels.
- Development/test overlap review and any exclusions.

Keep related source cases and paraphrases together when checking leakage. Report
counts for unchanged, adapted and researcher-written requests separately.

Missing required information should lead to clarification where appropriate.
An omitted network uses the existing Sepolia default; an explicitly conflicting
network is a separate boundary case. Preserve explicit slippage and other user
constraints. Omitted slippage uses the configured preparation default, and
unsupported conditions must not be silently discarded.

## 4. Experiments

Run three passes over the 400 prompts: **1,200 model calls in total**. Stages A
and C reuse each recorded LLM output; they do not call the model separately.
The first run of the 200 preselected primary wordings determines the main result.
Additional wordings and repeats measure consistency and do not increase the
independent sample size.

### A. Intent extraction and validation

Send all prompts to the configured LLM and validation layer. Compare both the
raw structured output and final validated intent with reviewed references.
Record parsing/schema failures, field errors, incorrect outcomes and lost
explicit constraints. Freeze the model and prompt configuration before testing.
The development configuration uses Groq-hosted `openai/gpt-oss-20b`; record the
actual final configuration rather than assuming it remains unchanged.

### B. Isolated graph verification

Send eligible, schema-valid reference intents directly to the graph verifier,
bypassing the LLM, regardless of whether Stage A interpreted the corresponding
request correctly. This isolates graph behaviour from extraction errors.
Incomplete or ambiguous requests stay at the validation boundary; do not invent
missing fields to make them graph inputs. Report both case-level totals and the
number of distinct graph inputs.

### C. Complete pipeline

Use the actual LLM output without manual correction through request, extraction,
deterministic validation, graph verification and structured decision. A case is
fully correct only when both the interpretation and final disposition match the
reference. A rejection following a misunderstood request is not full-pipeline
success. Record the earliest stage responsible for each incorrect result.

### D. Relationship mutations and baseline

Construct 12 initially valid fixtures: four Uniswap and eight Aave. Each has an
unchanged control and five mutations, changing one relationship at a time:

1. Action-function link.
2. Contract-function link.
3. Deployment-contract binding.
4. Deployment-resource membership.
5. Resource-asset link.

This gives **12 controls + 60 mutations = 72 scenarios**. Run the full verifier
and an entity-existence-only baseline on the same inputs while holding other
validation policies fixed. A broken mandatory path must prevent approval; the
precise non-approval must follow the declared knowledge-completeness policy.
Use isolated Neo4j test data, not the demonstration database.

### E. Knowledge maintenance and availability

Test six states for each protocol, giving **12 scenarios**:

1. Fresh, complete knowledge.
2. Stale knowledge.
3. Incomplete coverage.
4. A relationship removed or deactivated after a completed refresh.
5. A failed source refresh.
6. Unavailable Neo4j.

Distinguish relationship mismatches, insufficient evidence and infrastructure
errors. Database unavailability is an operational failure, not a correct semantic
rejection. A failed refresh must follow the declared snapshot-retention and
freshness policy; it must not automatically become a semantic rejection.

## 5. Measurements, timing and uncertainty

| Area | Measures |
|---|---|
| Intent | JSON/schema validity, per-field accuracy, entirely correct intents |
| Graph | Decision correctness, false approvals, false rejections, correct reasons |
| Complete pipeline | Correct interpretation and correct final disposition together |
| Robustness | Agreement between paraphrases and across repeated runs |
| Traceability | Expected contract, function, assets, relationship path or failure reason |
| Performance | Percentage within 2,000 ms, median, p95, maximum, failures and timeouts |

Report results by category and stage. An improper approval means approving a
case that should not be approved. Do not count database outages or unperformed
checks as correct rejections or passes. Assess explanations against the reviewed
reference evidence rather than merely checking whether an explanation is present.

### R6: two-second requirement

Start timing when a complete structured intent reaches the graph-verification
entry point. Stop when the structured decision is available. Exclude LLM
generation, wallet checks and transaction execution.

The target remains **at least 95% of eligible verification requests within
2,000 ms**. Keep first requests and slow requests in the measurements. Report the
within-threshold fraction and slow cases explicitly; p95 alone is insufficient.
Separate repeated calls from first occurrences of distinct graph inputs so cache
effects and repeated inputs remain visible.

### Prospective sample size

The proposal uses 140 non-approvable primary scenarios to study false approvals.
Its planning comparison is a 10% reference false-approval rate against a 3%
alternative at a 5% significance threshold [4]. Under the stated independence
assumptions, at most seven false approvals in 140 negative scenarios would meet
the planned test, with approximately 94% power at a 3% rate.

These are planning assumptions requiring supervisor confirmation, not observed
results or a real-world security guarantee. Report 95% confidence intervals for
the main proportions [5]. Repeats and paraphrases must not inflate the primary
denominators; report the family structure and limitations of independence.

## 6. Supplementary wallet and handover evaluation

Keep these cases separate from the 400-prompt benchmark.

| Boundary | Cases | Coverage |
|---|---:|---|
| Local policy and preparation | 13 | Destinations, expiry, value limits, balances/allowances, transaction data and slippage |
| Verified-operation handover | 3 | Parameter changes, expired capability and reused capability |
| API response handling | 12 | Authority/policy changes and injected wallet outcomes, including simulated success |
| Documented missing protections | 3 gaps | Connected-wallet/backend-signer binding, cumulative ERC-20 spending budgets and persistent receipt reconciliation |
| Read-only Sepolia observations | 5 operations, if policy permits | One swap and the four Aave actions |

There are **28 implemented controlled cases plus three separately reported
gaps**. Mocked outcomes show fixture or API behaviour, not live on-chain
enforcement. The previous five-operation observation stopped at an expired
policy before preparation; it did not assess actual balances, allowances,
quotes, collateral, debt or withdrawable positions. Current Aave preparation
does not independently check all position conditions or simulate the complete
operation. Report these limits explicitly. Transaction submission is not required.

## 7. Requirements assessment and comparison

After the experiments, apply the Chapter 2 criteria to the implemented prototype.
For R1-R5, reuse its four assessment levels and mandatory conditions; use the
existing numerical threshold for R6. Justify each rating with specific evidence.
Untested or unimplemented protections must not be rated as demonstrated.

| Requirement | Evidence |
|---|---|
| R1: Intent | Stage A; field/exact-intent results, defaults, ambiguity and constraints |
| R2: Relationships | Stage B reference intents and Stage D mutations/baseline |
| R3: Knowledge | Provenance and Stage E freshness, coverage and refresh outcomes |
| R4: Enforcement | Handover/capability cases, wallet policy and documented gaps |
| R5: Traceability | Rule identifiers and checked evidence paths/reasons in B, D and E |
| R6: Latency | Fraction of eligible decisions returned within 2,000 ms |

For the State of the Art comparison, retain the five Chapter 2 approach groups
and their existing ratings: execution-layer security, AI-agent execution,
knowledge retrieval/grounding, graph-based relationship analysis and
smart-contract security analysis. Add an evidence-based prototype row and explain
meaningful differences and limitations.

This is a requirements-based capability comparison. It does not claim that the
published systems were run on this benchmark. The direct experimental comparison
is the entity-existence-only baseline in Stage D. Numerical superiority over
systems such as Arbiter would require a separate matched benchmark and is outside
this plan.

## 8. Existing development evidence

These runs informed development and are not final held-out accuracy results.
The [saved status](evaluation/stage_reports/STATUS_2026-10-13.md) records their
boundaries; the [evaluation guide](evaluation/README.md) maps runners and artifacts.

| Development run | Recorded observation | Interpretation |
|---|---|---|
| Intent pilot, 11 October | 203/500 draft status matches | Intent-only pilot; no graph/wallet evaluation |
| Constraint regression, 12 October | 59/60 draft status matches | Different targeted dataset; not a before/after accuracy comparison |
| Graph pilot, 12 October | 136 cases, 28 distinct inputs, three passes/408 calls; all matched draft references | Snapshot conformance, not independent protocol truth; references still require researcher review |
| Graph timing | First pass 134/136 within two seconds; first distinct inputs 26/28 | Repeated inputs affect timing and denominators |
| Controlled wallet pilot, 12 October | 28/28 implemented cases matched; three gaps | Controlled behaviour, including mocks; no proof of live execution |
| Read-only policy observation, 13 October | Five graph-approved operations blocked by expired policy | No preparation or submission reached |

## 9. Work remaining before final execution

1. Complete source selection, overlap/leakage review and independent evidence checks.
2. Construct and human-review the 200 families/400 prompts; freeze primary wordings.
3. Construct and review the 72 relationship scenarios and 12 lifecycle scenarios.
4. Resolve implementation/policy questions, then freeze the graph snapshot, model,
   prompts, validation rules, freshness policy, software versions and timing settings.
5. Run A-E and the implemented wallet cases with versioned inputs, outputs, reasons,
   errors and timings. Reuse the recorded LLM outputs between A and C.
6. Analyse errors, evidence quality, latency, uncertainty and limitations against R1-R6.

The supplied PDF asks the supervisor to confirm:

- Whether 200 scenarios / 400 prompts are appropriate, or more are needed.
- Whether the 10% reference and 3% alternative false-approval assumptions are acceptable.
- Whether the 72 relationship and 12 knowledge-lifecycle scenarios provide appropriate scope.

Repository clarification: the proposed Uniswap diagram does not yet change the
implemented Aave-based token-admission policy. Resolve that policy and any needed
reference revisions before freezing the final benchmark. Historical graph results
remain tied to their original admitted snapshot. The current verifier represents
database unavailability as `INSUFFICIENT_EVIDENCE`; analysis must still identify
the operational cause rather than count it as a correct relationship rejection.

## References and document versions

References reproduced from the supplied PDF:

1. [INTENT-TX-18K Uniswap samples](https://github.com/duanyiyao/intent-tx-18k/blob/main/dataset/eg_uniswap_samples.json).
2. [Aave V3 Pool documentation](https://aave.com/docs/aave-v3/smart-contracts/pool).
3. [Uniswap V3 single-hop swapping](https://developers.uniswap.org/docs/protocols/v3/guides/swapping/single-hop-swapping).
4. [NIST/SEMATECH: sample sizes required](https://www.itl.nist.gov/div898/handbook/prc/section2/prc242.htm).
5. [NIST/SEMATECH: confidence intervals for proportions](https://www.itl.nist.gov/div898/handbook/prc/section2/prc241.htm).

The current source is the five-page PDF supplied on 15 October, saved under its
14 October file date. SHA-256:

```text
6b062ec4be844ca61365cc9941c47834b1226682ba6920759d76ad143eb08dba
```

The earlier seven-page [technical PDF](output/pdf/Revised_Evaluation_Plan.pdf)
and matching [Word document](output/documents/Revised_Evaluation_Plan.docx)
remain historical supporting artifacts. They are not matching copies of the
newer five-page source. The [initial 120-query proposal](docs/archive/EVALUATION_PLAN_initial.md)
is also retained for history and is superseded.
