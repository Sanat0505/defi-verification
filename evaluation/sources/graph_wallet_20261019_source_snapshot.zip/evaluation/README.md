# Evaluation guide

Start with the [saved status](stage_reports/STATUS_2026-10-13.md) for completed
development results and the [current plan](../EVALUATION_PLAN.md) for the proposed
held-out thesis study. Existing datasets and reports are development evidence;
the proposed 400-prompt/200-family benchmark has not been constructed or run.
The current Markdown plan follows the supplied five-page PDF. The earlier
seven-page technical documents remain supporting history; see the
[artifact index](../output/README.md) for the distinction.

## Choose the experiment

Run modules from the repository root using the project Python environment.

| Runner | Inputs and purpose | External work |
|---|---|---|
| `evaluation.runner` | Original `datasets/cases.json`; prompt through interpretation and graph verification | LLM and Neo4j; no wallet submission |
| `evaluation.sourced_runner` | `sourced_cases.json`, `expanded_500_cases.json` or `constraint_regression_v1.json`; interpretation against draft references | LLM only; no graph or wallet evaluation |
| `evaluation.snapshot_check` | Current Sepolia deployment freshness | Read-only Neo4j |
| `evaluation.graph_runner` | Reference intents from development datasets and structured boundary controls | Read-only Neo4j in evaluation mode; no LLM or wallet |
| `evaluation.wallet_runner` | `datasets/wallet_cases.json`; implemented controls, injected outcomes and gap records | Local Node.js checks with a temporary policy and mocked external outcomes |
| `evaluation.wallet_live_check` | Five operations using the existing wallet policy | Read-only graph/policy checks; live preparation only if permitted; no renewal or submission |

`graph_runner` also has a refresh mode. Refreshing graph knowledge requires
separate authorization; it is not part of a read-only evaluation run.

The dataset builders, `source_import.py`, `graph_stage.py`, `metrics.py` and
`summarize_expanded_results.py` support these experiments. They remain separate
because they preserve source provenance, reference construction and analysis.

## Find the evidence

| Location | Contents |
|---|---|
| `datasets/` | Versioned cases, expected interpretations and review metadata |
| `sources/` | Source manifests, pinned revisions and license notices |
| `sourced_reports/` | Earlier sourced development pilot and prerequisite checks |
| `expanded_reports/` | 500-query interpretation experiment |
| `constraint_reports/` | Separate 60-query constraint regression |
| `graph_reports/` | Earlier graph prerequisites, including stale-knowledge observations |
| `stage_reports/graph/` | Authorized refresh record, snapshots, draft references and graph evaluation |
| `stage_reports/wallet/` | Controlled wallet evaluation and live policy observation |
| `archives/` | Source backups needed to interpret historical code hashes |

The pinned `.cache/intent-tx-18k/` source files are research inputs, including
out-of-scope examples used for boundary cases. They are deliberately retained
for offline reproduction. `evaluation.source_import` can recreate them from
the recorded commit and checksums. The source archive also contains exact copies
of the earlier document generators, rendered pages and QA records, so their
duplicate working copies under `tmp/` are no longer needed.

The default pipeline and wallet runners write new reports under `reports/`
and `wallet_reports/`. Those locations differ from the saved stage reports.

## Interpretation limits

- The 500-query pilot and 60-query regression use different datasets; they are
  not a matched before/after comparison.
- The graph pilot has 136 cases but only 28 distinct graph inputs. Its 408 calls
  include three passes and measure draft snapshot conformance.
- The controlled wallet evaluation has 28 implemented scenarios and three gap
  records. Injected failures are not live on-chain protection tests.
- The 13 October live observation stopped at policy expiry, before preparation.
- References still need researcher review. Repeats and paraphrases do not add
  independent cases, and graph approval does not establish wallet readiness.

Detailed methods remain in [SOURCED_EVALUATION.md](SOURCED_EVALUATION.md),
[EXPANDED_EVALUATION.md](EXPANDED_EVALUATION.md) and
[CONSTRAINT_HANDLING.md](CONSTRAINT_HANDLING.md). These describe their respective
development experiments, not interchangeable versions of the final plan.
