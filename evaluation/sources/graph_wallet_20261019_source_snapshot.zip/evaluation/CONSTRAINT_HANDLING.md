# Intent constraints and slippage: implementation v1

## Scope and decision policy

The prototype still supports one Uniswap V3 exact-input swap or one Aave V3
supply, withdraw, borrow or repay operation on Ethereum Sepolia. This change
does not add arbitrary DeFi protocols or make the LLM a blockchain authority.

1. The model extracts semantic fields plus `slippage` and `unhandled_constraints`.
2. Deterministic text checks supplement the model for known unsupported conditions
   and check that recognized user slippage has not been omitted or changed.
3. Normalization converts explicit aliases and validates the candidate. An
   unsupported condition yields `UNSUPPORTED`, an invalid representable numeric
   parameter yields `REJECTED`, and missing required fields need clarification.
   Unsupported conditions take precedence if a request has several problems.
4. Only an accepted complete candidate reaches graph verification. A graph
   approval issues a server-held, single-use, expiring execution capability.
5. The capability snapshots the effective slippage. Execution rechecks graph
   authority and passes the saved limit to the existing wallet executor.

`APPROVED` at step 3 means ready for graph verification, not transaction approval.
Graph freshness, available routes/reserves, balances, debt/collateral, allowance
and wallet policy are separate checks. Interpretation success does not imply
that an operation is currently executable on-chain.

## Network aliases

`Sepolia`, `Ethereum Sepolia`, `Sepolia testnet`, `Sepolia test network`,
`Ethereum Sepolia testnet`, `Ethereum Sepolia test network` and
`Sepolia (Ethereum testnet)` normalize to Ethereum Sepolia / chain ID 11155111.
Case and punctuation are normalized. Base Sepolia and Arbitrum Sepolia are NOT
Ethereum Sepolia. The configured application network remains the default when
the user omits a network; the model must preserve explicitly stated networks.

## Slippage policy

- Supported only for Uniswap V3 swaps: inclusive maximum tolerance in percent or
  basis points, exactly representable as **1 through 500 whole bps** (0.01%-5%).
- `0.25%` and `25 bps` both mean `slippage_bps: 25`. This uses decimal arithmetic,
  never floating-point rounding. `0.255%`, `2.5 bps`, zero, negatives and values
  above 5% are rejected, not rounded or replaced with a default.
- Missing slippage remains null in the semantic intent. The effective execution
  setting comes from `SWAP_SLIPPAGE_BPS` (default 100 = 1%) at verification time.
  Both explicit and default settings are saved in the capability. The UI shows
  the effective maximum and whether it was user-specified or configured.
- The existing wallet quote uses that tolerance to compute `amountOutMinimum`.
  This is a quote-relative tolerance, not a price-impact, gas, deadline or absolute
  minimum-output guarantee. No wallet transaction was submitted to test this change.
- `slippage must be low`, missing units, conflicting limits and strict bounds
  such as `less than 0.25%` are unsupported in v1. The text guard intentionally
  recognizes a limited set of explicit numeric phrasings. It blocks rather than
  defaults when a slippage mention is not recognized or is not preserved by the model.
- A clarification that only fills a missing field retains the saved limit. To
  add or change a limit during clarification, resubmit the complete operation.
- Clients cannot pass or override slippage at `/api/execute`; that endpoint still
  accepts only the verification capability ID and wallet address.

## Unsupported conditions and limits of detection

Known guarded conditions include deadlines, custom recipients/beneficiaries,
gas/fee budgets, absolute minimum output, fiat/relative quantities, fixed-rate
lending, health-factor conditions, price-impact limits, multiple operations,
conditional execution and exact-output/input-budget requests. The model can
also report conditions not covered by the text checks.

These checks are deliberately conservative, not a complete natural-language
parser or a proof against every prompt injection. They may overblock incidental
or negated mentions, and novel wording may escape detection. Version/network
extraction still depends on the model preserving user wording before deterministic
normalization. Keep these limitations explicit in the thesis.

## Manual examples

| Query | Expected interpretation |
|---|---|
| Swap 10 USDC for WETH on Uniswap V3 on Sepolia test network, maximum slippage 0.25%. | Accepted candidate; 25 bps; graph/wallet checks still required |
| Withdraw 10 USDT from Aave V3 on Ethereum Sepolia. | Accepted candidate; graph and wallet position still required |
| Swap 10 USDC for WETH on Uniswap V3 on Sepolia, slippage 0.25%, finish within one minute. | Unsupported deadline; no capability |
| Swap 10 USDC for WETH on Uniswap V3 on Base Sepolia. | Unsupported network |
| Swap 10 USDC for WETH on Uniswap V3 on Sepolia, slippage 0.255%. | Invalid precision; never rounded |

## Evaluation separation and reproducibility

The original 120/500-case datasets and their report files are preserved. Their
old scope labels are not silently rewritten to favor the new implementation.
In particular, old slippage cases need independently reviewed, versioned labels
under the new support policy. A source query with slippage AND a deadline is
still unsupported; adding slippage support does not make its other conditions safe.

`datasets/constraint_regression_v1.json` contains 60 new synthetic development
cases, authored with expected outcomes before model execution. The generator
`build_constraint_regression.py` refuses to overwrite that version. The source
is the documented implementation policy, not the original transaction dataset.
These are assistant-drafted references requiring independent researcher review.
Cases share category families and are not 60 independent observations.

Run the versioned pilot with:

```powershell
.\venv\Scripts\python.exe -m evaluation.sourced_runner --dataset evaluation/datasets/constraint_regression_v1.json --output-dir evaluation/constraint_reports --delay 0.25 --checkpoint-every 5
```

Each fresh run creates JSON plus Markdown with dataset snapshot/hash, code hashes
(including the new guard and slippage conversion), model settings, normalized
intents, condition flags, decisions, mismatches and per-request interpretation
latency. It does not retain the raw provider response. No graph or wallet is
called, and this latency is not the separate R6 graph-verification measurement.

The offline tests exercise normalization and parser behavior with mocked model
outputs, plus the pipeline/API capability handoff with graph, whitelist and wallet
calls mocked. They check default freezing, explicit-limit preservation, replay
prevention, clarification safety and client-override rejection. The live development
run instead calls the configured Groq model and the real deterministic guards.
Neither is a live transaction execution test or final end-to-end thesis evaluation.

## Recorded development result: 2026-10-12

- Offline suite: **146 Python tests passed**; the existing Starlette/httpx
  deprecation warning remains. JavaScript syntax check passed, and **5 isolated
  rendering fixtures passed** (`node tests/frontend_slippage.cjs`). These are
  rendering-function checks, not browser layout/visual tests.
- Live model: **60/60 cases completed**, using `openai/gpt-oss-20b` through Groq
  plus the actual constraint checks and normalization. **59/60 exact decision
  matches**, **26/26 reference-field matches** where structured references were
  supplied, **0 improper approvals**, **0 service errors**.
- All 22 approval-reference cases reached interpretation approval; all 38
  nonapproval-reference cases were blocked or requested clarification.
- The remaining mismatch is `CONSTRAINT-V1-024`: `slippage -0.25%` was classified
  as `UNSUPPORTED` rather than the reference `REJECTED`. The model reported
  `negative slippage` in `unhandled_constraints`, whose current validation
  precedence wins over numeric validation. This is a diagnostic-category
  inconsistency, not an improper approval. The reference was NOT changed to
  count it as correct.
- Interpretation latency p50 was 8051.81 ms, p95 9386.67 ms. This includes model
  calls and is not a measurement of the graph-only R6 boundary. It does not
  establish compliance with any end-to-end two-second requirement.
- This is a **new targeted development run**, not a rerun of all 500 baseline
  cases or an estimate of overall thesis accuracy. Independent reference review
  and a separately frozen holdout remain necessary. Graph, wallet-policy and
  execution evaluation must stay separate from this interpretation result.

Full normalized outputs, expected labels, errors and metadata:
[JSON report](constraint_reports/sourced-intent-20261012T192912651221Z.json).
[Generated summary](constraint_reports/sourced-intent-20261012T192912651221Z.md).
No transaction, graph refresh or real whitelist write was performed.

Restart the backend if it is not running with automatic reload, then refresh
the browser to load the updated UI. A valid example can still stop at graph
verification if knowledge is stale or a relationship is not admitted; that is
separate from whether the intent/slippage was interpreted correctly.
