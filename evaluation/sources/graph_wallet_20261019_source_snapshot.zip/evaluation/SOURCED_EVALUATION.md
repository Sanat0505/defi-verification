# Source-derived evaluation dataset

An additional **500-case exploratory set** is now available in
[expanded_500_cases.json](datasets/expanded_500_cases.json). See
[Expanded evaluation](EXPANDED_EVALUATION.md) for sampling, actual-run JSON output,
checkpoint/resume instructions and interpretation limits. The original 120 cases
and their proposed 90-case holdout described below remain unchanged.

## What was added

A 120-case draft in [sourced_cases.json](datasets/sourced_cases.json), with a readable [case review sheet](datasets/SOURCED_CASE_REVIEW.md). It contains 30 development cases and 90 proposed test cases. The default runner evaluates development cases only.

This extends the evaluation material without changing the application, its prompt, graph contents, or wallet policies. The old dataset and its reports remain unchanged. The legacy runner rejects this new dataset because interpretation reference statuses must not be confused with unconditional graph outcomes.

| Case stratum | Count | Purpose |
|---|---:|---|
| Unchanged INTENT-TX-18K queries | 18 | Preserve 12 Uniswap, 3 Compound, and 3 CoW source queries, including all constraints |
| Explicitly labelled adaptations | 18 | 12 V3/Sepolia context adaptations retaining constraints; 6 explicit Compound/CoW protocol adaptations |
| Simplified Uniswap controls | 24 | New source-inspired scenarios, two paraphrases per family; every changed asset/amount and omitted condition is disclosed |
| Documentation-based synthetic cases | 60 | 44 Aave cases and 16 Uniswap boundary cases |
| Total | 120 | Development 30; proposed test 90 |

The 44 Aave cases comprise 24 complete supply/withdraw/borrow/repay requests, 16 missing/invalid/network boundary cases, and 4 unsupported-feature cases. They are assistant-authored examples, NOT historical Aave user requests or extracts from an Aave query corpus.

## Source audit: important differences from the original assumption

Sources were pinned to commit `37bd0f345efb166e3cebc6839e75481e57ce3c90` in [INTENT-TX-18K](https://github.com/duanyiyao/intent-tx-18k). The [manifest](sources/intent_tx_18k_manifest.json) records file hashes, byte counts, and audit counts. Raw inputs are cached under the ignored `.cache/intent-tx-18k/` directory; their MIT [license](sources/INTENT_TX_18K_LICENSE.txt) is retained.

The actual pinned files contain 6,000 Uniswap, 7,000 Compound, and 7,000 CoW records: 20,000 records, despite the repository's name. These are paired intent/transaction records, not 20,000 independent user queries.

The [Uniswap file](https://github.com/duanyiyao/intent-tx-18k/blob/37bd0f345efb166e3cebc6839e75481e57ce3c90/dataset/eg_uniswap_samples.json) has:

- 6,000 proposed transactions labelled `Uniswap V2`, all with transaction `chain_id=1`.
- Zero query texts explicitly mentioning V3.
- 2,911 distinct query texts and 1,461 transaction-hash families.
- Frequent slippage, minimum-output, deadline, and dollar-denominated quantity expressions.

Therefore, there is no authentic V3 transaction subset to extract from this file at this commit. Its transaction metadata is retained for provenance, not inserted into the query's reference intent. Version-ambiguous text is not labelled V2 merely because its paired transaction says V2.

Uniswap V3/Sepolia adaptations were explicitly authorized by the user. They are not described as original V3 benchmark samples. Constraint-preserving adaptations alter only the named protocol/network context. Simplified controls are NEW scenarios, not faithful paraphrases: their original queries and transformation logs remain available alongside the unchanged and constraint-preserving cases. In particular, replacing ETH with WETH or a dollar value with a token quantity is disclosed as a changed scenario, never a normalization or currency conversion.

The original `PASS`/`REJECT` labels are stored as `upstream_label_not_gold`. They assess the proposed transaction against the intent, which is a different task. No reference outcome is copied from them. Source labels are used only to include examples from both upstream classes in the purposive sample.

The synthetic operation vocabulary is based on [Aave V3 Pool documentation](https://aave.com/docs/aave-v3/smart-contracts/pool) and [Uniswap V3 single-hop swapping documentation](https://developers.uniswap.org/docs/protocols/v3/guides/swapping/single-hop-swapping). Documentation establishes the operation's meaning, not that a particular Sepolia token relationship is present in your graph. These are evolving documentation pages, not immutable snapshots; capture the exact versions you cite when freezing the thesis experiment.

## What the reference labels mean

All labels are assistant-drafted and pending independent researcher review. They are proposed normative expectations, not model-generated ground truth and not results from the verifier under test.

| Status | Interpretation-stage meaning |
|---|---|
| APPROVED | Complete, in-scope basic intent, ready for subsequent graph verification |
| NEEDS_CLARIFICATION | Required semantic information is absent; do not guess it from transaction metadata |
| UNSUPPORTED | Explicit unsupported protocol, network, version, or unrepresentable feature |
| REJECTED | Invalid stated quantity or identical swap assets |

Review the chosen error-precedence policy: for example, a source query that omits the protocol is assigned NEEDS_CLARIFICATION, while a complete named-protocol query with unsupported constraints is assigned UNSUPPORTED. A different safe rejection may be a strict-label mismatch without being an improper approval. Infrastructure errors must not count as successful semantic rejections.

The current intent model has no fields for user-specified slippage, deadlines, output minimums, beneficiaries, or fiat-price conversion. Constraints are retained in the queries to test whether the application safely refuses/clarifies unsupported requests. Correctly extracting basic fields is insufficient to pass such a case if the request is nevertheless approved with its constraint discarded.

`expected_intent` contains only the supported-schema fields being assessed, with explicit nulls where missing-field behavior is checked. Its exact-match denominator is a subset of the corpus. For constrained cases it is not a complete representation of the user's intent. Report disposition correctness jointly with field correctness.

`expected_graph_outcome` is intentionally null. Complete supported requests have a conditional graph reference, not an unconditional approval label. Before an end-to-end graph experiment, independently inspect and record the fresh snapshot's deployment/action/contract/function/token/pool/reserve relationships. Missing paths require a coverage assessment before choosing REJECTED versus INSUFFICIENT_EVIDENCE. Never populate gold labels from the production verifier's answer.

## Reproducible commands

Run from the project root with the existing virtual environment.

Validate the committed draft offline:

```powershell
.\venv\Scripts\python.exe -m evaluation.sourced_runner --validate-only
```

Run the 30 development cases through the real configured LLM, without graph or wallet calls:

```powershell
.\venv\Scripts\python.exe -m evaluation.sourced_runner --split development --repeats 1
```

Repeat development cases for response consistency:

```powershell
.\venv\Scripts\python.exe -m evaluation.sourced_runner --split development --repeats 3
```

These commands use the configured model API and can consume provider quota. First runs determine primary per-case scores; later runs assess consistency and do not increase the independent case count. This runner does not measure wallet behavior or R6.

Check graph freshness without changing the database:

```powershell
.\venv\Scripts\python.exe -m evaluation.snapshot_check
```

Reproduce inputs and rebuild an assistant draft:

```powershell
.\venv\Scripts\python.exe -m evaluation.source_import --source uniswap --source compound --source cow --source license
.\venv\Scripts\python.exe -m evaluation.build_sourced_dataset --output evaluation/datasets/sourced_cases_rebuilt.json --review-output evaluation/datasets/SOURCED_CASE_REVIEW_REBUILT.md
```

Use a new output path when rebuilding after manual review; do not overwrite your reviewed labels. Downloads and cached inputs are checked against pinned SHA-256 values.

## Development pilot already performed

The initial [30-case pilot](sourced_reports/sourced-intent-20261011T165358144136Z.md) used the real configured model (`openai/gpt-oss-20b`, temperature 0):

- 23/30 reference dispositions matched.
- 19/19 supported-schema field references matched.
- 18/19 cases with field references matched both interpretation and disposition/required clarification checks.
- Six unsupported-constraint requests received APPROVED at the interpretation stage.
- One additional mismatch was a REJECTED invalid-amount response instead of the reference UNSUPPORTED response. It did not approve the request.
- No service errors, graph calls, wallet calls, or broadcasts occurred.

The pilot's dataset hash is recorded in its JSON report, with every evaluated query and reference retained. After that pilot, metadata was expanded to include the source commit and the explicit template-overlap limitation; queries and reference labels were not changed. Later runner versions additionally embed the full dataset snapshot in each report. This pilot is preliminary evidence, not the final thesis test-set result.

The [graph preflight](sourced_reports/graph_snapshot_preflight.json) found the Sepolia knowledge about 196 hours old against a 168-hour configured freshness limit. No synchronization or graph mutation was performed. Freshness must be restored through the normal, separately reviewed synchronization workflow before testing fresh-knowledge positive cases. Do not widen the threshold or rewrite labels merely to obtain passes.

## Review, freezing, and remaining evaluation work

1. Review source fidelity, every transformation, the expected fields, and the scope/error-precedence policy. Approve or correct annotations on semantic grounds, not by matching model output.
2. Mark actually reviewed cases `researcher_reviewed`, record reviewer/date and a version identifier, and save a frozen dataset copy.
3. Keep source/scenario families together across splits. The provided split is family-disjoint but NOT template-disjoint: related synthetic sentence templates appear in both splits. Do not claim broad linguistic generalization or statistical representativeness from it.
4. The 90 test cases have not been sent to the application model in this work. The runner refuses an unreviewed test split unless `--allow-unreviewed` is explicitly supplied; using that option creates another exploratory pilot, not final evidence.
5. Once reviewed and frozen, run the test split with repeated trials using the frozen file. Do not tune the prompt on final-test outputs and then report them as held-out performance.
6. Conduct isolated graph tests, relationship-mutation/entity-only comparisons, knowledge-maintenance tests, wallet tests, and R6 measurements separately. This dataset does not complete those experiments.

No application behavior was changed to make these cases pass. In particular, the observed unsupported-constraint approvals remain visible as evaluation findings.
