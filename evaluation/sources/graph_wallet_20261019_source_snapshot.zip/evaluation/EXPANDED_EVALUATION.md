# Expanded 500-query evaluation

This adds **500 new exploratory cases**, leaving `datasets/sourced_cases.json`
(120 cases, including its 90-case proposed holdout) unchanged. It does not
overwrite the earlier 30-case development report. Across both files there are
620 unique queries; completing this new run means 530 distinct queries have
actually been evaluated, not 620.

## What is measured

The real configured LLM and production deterministic intent normalization are
called for each query. The JSON records the query, expected status/reference
fields, actual normalized intent, actual status, missing fields, diagnostic,
latency, provenance and scores. It also embeds the dataset snapshot and records
model, source commit, code hashes, selected IDs, completion status and input hash.

`APPROVED` means **accepted for subsequent graph verification**, not permission
to broadcast a transaction. No Neo4j verification, wallet evaluation, balance
check, transaction simulation or transaction submission is performed here.
Latency includes the LLM and is not the thesis R6 graph-only timing experiment.

References are assistant/rule-authored **drafts requiring researcher review**.
Current percentages are agreement with those references, not a final measured
accuracy of the entire system. References are fixed before model execution;
they are not copied from model outputs or upstream transaction-alignment labels.

## Composition

| Stratum | Cases | Purpose |
|---|---:|---|
| Unchanged Uniswap source queries | 120 | Preserve actual upstream wording and constraints |
| Explicit V3/Sepolia adaptations of those queries | 120 | Change only named context; retain all constraints |
| Unchanged Compound/CoW source queries | 30 | Unsupported protocol or missing protocol handling |
| Explicit Compound/CoW adaptations | 30 | Unambiguously unsupported protocol tests |
| Synthetic Uniswap core requests | 40 | Linguistic variants, amounts, token direction, ETH preservation |
| Synthetic Aave core requests | 60 | Supply, withdraw, borrow and repay |
| Synthetic boundary cases | 100 | Missing information, invalid values, unsupported features/networks/protocols |
| **Total** | **500** | |

There are **350 declared families**, including 150 original/adapted pairs.
Synthetic cases also share **57 language/boundary template IDs**. Thus 500
queries are not 500 independent observations. Do not apply a simple independent
binomial confidence interval or claim template-disjoint generalization.

The target-status distribution is deliberately stress-test heavy: 100 APPROVED,
343 UNSUPPORTED, 41 NEEDS_CLARIFICATION, 16 REJECTED. A single pooled percentage
is sensitive to this mixture; always also report results by category/origin and
core requests separately. This is not a representative sample of user traffic.

## Sources, selection and provenance

The pinned INTENT-TX-18K commit is
`37bd0f345efb166e3cebc6839e75481e57ce3c90`. Source files and hashes are documented
in `sources/intent_tx_18k_manifest.json`; the upstream MIT notice is preserved in
`sources/INTENT_TX_18K_LICENSE.txt`.

All source Uniswap transaction metadata at this commit is V2/mainnet. It is
therefore incorrect to describe the originals as an existing V3/Sepolia dataset.
The adaptations are explicitly labelled. Proposed transaction fields never
supply unstated query fields. Upstream PASS/REJECT labels evaluate a different
intent/transaction alignment task and are retained solely as provenance.

Historical transaction families are sampled reproducibly with seed `20261011`;
one original wording per selected family is retained. Selection does not depend
on upstream labels or model predictions. Uniswap screening requires an explicit
Uniswap mention, a slippage mention and a numeric percentage; this is a narrow
rule-screened constraint stratum, not automatic comprehensive semantic review.
All baseline families and normalized query texts are excluded. New original
queries are deduplicated after whitespace normalization and case folding.

Synthetic requests are assistant-authored scenarios grounded in the operation
definitions in the [Uniswap single-swap documentation](https://developers.uniswap.org/docs/protocols/v3/guides/swapping/single-hop-swapping)
and [Aave Pool documentation](https://aave.com/docs/aave-v3/smart-contracts/pool).
Those documents do not prove local Sepolia graph membership, liquidity or wallet
feasibility. ETH is deliberately preserved as ETH rather than rewritten as WETH.

Original queries can contain multiple reasons not to proceed (fiat amounts,
approximate quantities, slippage, missing protocol, deadlines). Researcher review
must settle disposition precedence. The JSON separately counts non-approval
without service errors, so a conservative rejection is distinguishable from
silently accepting a reduced request even when its exact status differs from
the draft reference. This separate count is not substituted for exact-status
agreement.

## Reproduce and run

Run from the repository root with the project Python environment. The generator
requires the already checksum-validated public source cache and refuses to
overwrite an existing generated file:

```powershell
.\venv\Scripts\python.exe -m evaluation.build_expanded_dataset --output evaluation/datasets/expanded_500_rebuild.json
.\venv\Scripts\python.exe -m evaluation.sourced_runner --dataset evaluation/datasets/expanded_500_cases.json --validate-only
.\venv\Scripts\python.exe -m pytest -q
```

Real model evaluation uses the configured Groq API and consumes provider quota:

```powershell
.\venv\Scripts\python.exe -m evaluation.sourced_runner --dataset evaluation/datasets/expanded_500_cases.json --output-dir evaluation/expanded_reports --delay 0.25 --checkpoint-every 10
```

Requests are sequential. A JSON checkpoint is written initially, every ten
results, on service errors and on normal/handled interrupted exit. Three
consecutive service errors stop the run. Incomplete runs are explicitly marked
and must not be reported as 500 completed cases. A hard process kill may lose
up to the uncheckpointed results, not the whole run.

Resume with the same command plus `--resume <existing-report.json>`. The runner
checks dataset/model/code/selection consistency and skips completed case/run
pairs, including errors. It never overwrites observed failures with convenient
retry successes. Use a separate run if comparing a changed model or prompt.

The report retains `independent_cases` only for backward compatibility with the
old runner; it counts unique cases, **not statistically independent samples**.
Use `unique_cases`, `declared_families` and the correlation caveats when writing
the thesis.

For a smaller JSON containing core-request results, category breakdowns and all
reference mismatches, summarize a saved report offline:

```powershell
.\venv\Scripts\python.exe -m evaluation.summarize_expanded_results evaluation/expanded_reports/<run-name>.json
```

The analysis records the input report's SHA-256 and completion status. It does
not make extra model calls. It refuses to overwrite an existing output, so an
analysis of an incomplete checkpoint cannot silently become a final result.

## Before final thesis claims

Review the query/reference pairs independently, record corrections as a new
version (do not rewrite historical outputs), and freeze a final test set before
tuning the model or prompt. The original 90-case proposed holdout remains unrun;
its labels also still need review. This expanded set is now development evidence.

Graph and wallet tests remain separate. The last saved graph preflight found
stale deployment evidence beyond the configured 168-hour threshold. Do not
bypass freshness or relabel those results as semantic failures. A fresh reviewed
snapshot and explicit wallet-state fixtures are required for those experiments.
